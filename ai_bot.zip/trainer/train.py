import os

import numpy as np
import torch.optim as optim
import torch.nn as nn
from model.lstm_price_predictor import LSTMPricePredictor
from data.fetch_data import CryptoDataFetcher
from sklearn.preprocessing import MinMaxScaler
import torch


class Trainer:
    def __init__(self, model, epochs=50, learning_rate=0.001, seq_length=20):
        self.model = model
        self.epochs = epochs
        self.learning_rate = learning_rate
        self.seq_length = seq_length
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.loss_fn = nn.MSELoss()

    def prepare_data(self, df):
        scaler = MinMaxScaler()
        features = ['close', 'rsi', 'ema', 'adx', 'atr', 'volume']
        scaled_data = scaler.fit_transform(df[features])

        X, y = [], []
        for i in range(self.seq_length, len(scaled_data)):
            X.append(scaled_data[i - self.seq_length:i])
            y.append(scaled_data[i, 0])  # close

        X_tensor = torch.tensor(np.array(X), dtype=torch.float32)
        y_tensor = torch.tensor(np.array(y), dtype=torch.float32).unsqueeze(1)

        return X_tensor, y_tensor, scaler

    def train(self, X_tensor, y_tensor):
        dataset = torch.utils.data.TensorDataset(X_tensor, y_tensor)
        loader = torch.utils.data.DataLoader(dataset=dataset, batch_size=32, shuffle=True)

        for epoch in range(self.epochs):
            epoch_loss = 0
            self.model.train()

            for batch_X, batch_y in loader:
                self.optimizer.zero_grad()
                output = self.model(batch_X)
                loss = self.loss_fn(output, batch_y)
                loss.backward()
                self.optimizer.step()
                epoch_loss += loss.item()

            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch + 1}/{self.epochs}], Loss: {epoch_loss / len(loader):.4f}")

        return self.model


def train(symbol):
    timeframes = ['15m', '1h', '4h', '1d']
    fetcher = CryptoDataFetcher()

    symbol_dir = symbol.replace('/', '_')
    model_dir = f'trainer/models/{symbol_dir}'
    os.makedirs(model_dir, exist_ok=True)

    features = ['close', 'rsi', 'ema', 'adx', 'atr', 'volume']

    for timeframe in timeframes:
        print(f"⏳ Обучаю модель {symbol} [{timeframe}]...")

        market_data = fetcher.fetch_historical_data_multi_timeframe(symbol, timeframes=[timeframe])
        df = market_data[timeframe]

        if df.empty or any(col not in df.columns for col in features):
            print(f"⚠️ Данные для {symbol} [{timeframe}] пустые или неполные.")
            continue

        trainer = Trainer(LSTMPricePredictor(input_size=len(features)))
        X_tensor, y_tensor, scaler = trainer.prepare_data(df)

        trainer.train(X_tensor, y_tensor)

        model_path = f'{symbol_dir}_{timeframe}_lstm.pth'
        torch.save(trainer.model.state_dict(), os.path.join(model_dir, model_path))

        print(f"✅ Модель {symbol} [{timeframe}] сохранена.")
