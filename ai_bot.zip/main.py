import os
import threading
import torch
import numpy as np
import logging
from sklearn.preprocessing import MinMaxScaler
from transformers import pipeline
from bot.manage_coins import CoinManager
from bot.order_notifier import OrderNotifier
from data.fetch_data import CryptoDataFetcher
from data.cryptopanic_data import CryptoNewsFetcher
from data.market_analyzer import MarketAnalyzer
from data.news_summary import NewsSummarizer
from data.smart_coin_selector import SmartCoinSelector
from model.lstm_price_predictor import LSTMPricePredictor
from trading.binance_trader import BinanceTrader
from trainer.train import Trainer, train
from bot.telegram_bot import TelegramBot
from config import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID

logging.getLogger("transformers").setLevel(logging.ERROR)


# Подготовка данных для LSTM
def prepare_lstm_data(df, features=None, window_size=24):
    if features is None:
        features = ['close', 'rsi', 'ema', 'adx', 'atr', 'volume']

    scaler = MinMaxScaler()
    scaled_features = scaler.fit_transform(df[features])

    X, y = [], []
    for i in range(len(scaled_features) - window_size):
        X.append(scaled_features[i:i + window_size])
        y.append(scaled_features[i + window_size, 0])

    X, y = np.array(X), np.array(y)

    return (
        torch.tensor(X, dtype=torch.float32),
        torch.tensor(y, dtype=torch.float32).unsqueeze(1),
        scaler
    )


# Инициализация всех нужных компонентов
data_fetcher = CryptoDataFetcher()
trader = BinanceTrader()
coin_manager = CoinManager(trader, data_fetcher)

# Загружаем текущие монеты для торговли
symbols_to_trade = coin_manager.get_current_coins()

# Если монет нет, используем BTC/USDT по умолчанию
if not symbols_to_trade:
    default_coin = 'BTC/USDT'
    coin_manager.add_coin('BTC')
    symbols_to_trade = [default_coin]

# Таймфреймы которые используем
timeframes = ['15m', '1h', '4h', '1d']

# Проверяем наличие моделей по всем таймфреймам
for symbol in symbols_to_trade:
    symbol_dir = symbol.replace('/', '_')
    model_dir = f'trainer/models/{symbol_dir}'

    for timeframe in ['15m', '1h', '4h', '1d']:
        model_path = os.path.join(model_dir, f'{symbol_dir}_{timeframe}_lstm.pth')
        if not os.path.exists(model_path):
            print(f"⚠️ Модель для {symbol} [{timeframe}] отсутствует. Запускаю обучение...")
            train(symbol)
            break  # Если хотя бы одной модели нет, переобучаем всё сразу и выходим
        else:
            print(f"✅ Модель {symbol} [{timeframe}] уже существует.")

# Подгружаем модель для основного таймфрейма (1h) как пример
market_data = data_fetcher.fetch_historical_data_multi_timeframe('BTC/USDT')
historical_data = market_data['1h']

train_data, train_labels, scaler = prepare_lstm_data(historical_data)

model = LSTMPricePredictor(input_size=train_data.shape[2])

if os.path.exists('saved_lstm_model.pth'):
    model.load_state_dict(torch.load('saved_lstm_model.pth'))
    model.eval()
    print("✅ Загружена сохранённая LSTM модель!")
else:
    trainer = Trainer(model, epochs=200)
    trainer.train(train_data, train_labels)
    print("✅ LSTM модель обучена и сохранена!")

# Инициализация анализаторов
sentiment_analyzer = pipeline("sentiment-analysis", model='nlptown/bert-base-multilingual-uncased-sentiment')
translator_pipeline = pipeline("translation", model="Helsinki-NLP/opus-mt-en-ru")
summarization_pipeline = pipeline("summarization", model="facebook/bart-large-cnn")
summarizer = NewsSummarizer(translator_pipeline, summarization_pipeline)

news_fetcher = CryptoNewsFetcher(summarizer)
market_analyzer = MarketAnalyzer(news_fetcher)

# Инициализация Telegram-бота с правильными аргументами
telegram_bot = TelegramBot(
    TELEGRAM_TOKEN,
    model,
    scaler,
    data_fetcher,
    sentiment_analyzer,
    news_fetcher,
    summarizer,
    market_analyzer,
    symbols_to_trade
)

telegram_bot.coin_manager = coin_manager
telegram_bot.start(TELEGRAM_CHAT_ID)

# Запускаем уведомления о позициях
order_notifier = OrderNotifier(telegram_bot, telegram_bot.trader, interval=60)
order_thread = threading.Thread(target=order_notifier.check_positions, daemon=True)
order_thread.start()
