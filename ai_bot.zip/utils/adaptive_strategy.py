import pandas as pd
import json
import os

PARAMS_FILE = 'strategy_params.json'
METRICS_FILE = 'bot_metrics.csv'

def load_strategy_params():
    if os.path.exists(PARAMS_FILE):
        with open(PARAMS_FILE, 'r') as file:
            return json.load(file)
    else:
        return {"threshold_percent": 0.05, "sentiment_threshold": 0.6}

def save_strategy_params(params):
    with open(PARAMS_FILE, 'w') as file:
        json.dump(params, file, indent=4)

def adapt_strategy():
    params = load_strategy_params()

    if not os.path.exists(METRICS_FILE):
        print("⚠️ Метрики не найдены, используются параметры по умолчанию.")
        return params

    df = pd.read_csv(METRICS_FILE)

    total_trades = len(df)
    if total_trades == 0:
        print("⚠️ Нет данных о сделках для анализа, параметры не изменены.")
        return params

    winning_trades = df[df['pnl_percent'] > 0]
    losing_trades = df[df['pnl_percent'] < 0]

    win_rate = len(winning_trades) / total_trades * 100 if total_trades else 0
    avg_profit = winning_trades['pnl_percent'].mean() if not winning_trades.empty else 0
    avg_loss = losing_trades['pnl_percent'].abs().mean() if not losing_trades.empty else 0

    params = load_strategy_params()

    # Адаптация threshold_percent
    if win_rate < 50 and params['threshold_percent'] <= 0.2:
        params['threshold_percent'] += 0.01  # Повышаем порог для улучшения точности
    elif win_rate > 70:
        params['threshold_percent'] = max(0.01, params['threshold_percent'] - 0.005)  # Уменьшаем, если и так хорошая точность

    # Адаптация sentiment_threshold
    if avg_loss > avg_profit:
        params['sentiment_threshold'] += 0.05  # Повышаем порог, если потери выше прибыли
    else:
        params['sentiment_threshold'] = max(0.1, params['sentiment_threshold'] - 0.05)

    save_strategy_params(params)

    print(f"✅ Параметры стратегии адаптированы: {params}")
    return params
