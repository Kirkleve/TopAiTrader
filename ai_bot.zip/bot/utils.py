def analyze_sentiment(text, sentiment_analyzer):
    sentiment_result = sentiment_analyzer(text)[0]['label']
    rating = int(sentiment_result.split()[0])  # извлекаем цифру из '1 star', '5 stars'
    sentiment_score = (rating - 3) / 2  # от -1 до 1
    return sentiment_score
