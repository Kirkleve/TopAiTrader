import time
from config import TELEGRAM_CHAT_ID


class OrderNotifier:
    def __init__(self, bot, trader, symbol='BTC/USDT', interval=60):
        self.bot = bot
        self.symbol = symbol
        self.trader = trader
        self.interval = interval
        self.notified_positions = set()

    def check_positions(self):
        positions = self.trader.exchange.fetch_positions([self.symbol])

        for pos in positions:
            pos_amt = float(pos['contracts'])
            #entry_price = float(pos['entryPrice'])
            #unrealized_pnl = float(pos['unrealizedPnl'])

            if pos_amt == 0 and pos['symbol'] in self.notified_positions:
                msg = f"⚠️ Позиция по {self.symbol} закрылась по TP или SL.\n"
                pnl = float(pos['info']['realizedPnl'])
                result = "✅ Профит!" if pnl > 0 else "❌ Убыток"
                msg += f"{result} PnL: {pnl:.2f}$"

                self.bot.send_message(TELEGRAM_CHAT_ID, msg)
                self.notified_positions.remove(self.symbol)

            elif pos_amt > 0 and self.symbol not in self.notified_positions:
                self.notified_positions.add(self.symbol)

    def start_monitoring(self):
        print("🟢 Запуск мониторинга ордеров TP и SL...")
        while True:
            try:
                self.check_positions()
                time.sleep(self.interval)
            except Exception as e:
                print(f"❌ Ошибка проверки позиций: {e}")
                time.sleep(self.interval)
