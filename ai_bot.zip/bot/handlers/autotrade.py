import torch
import numpy as np
import os
from sklearn.preprocessing import MinMaxScaler
from bot.utils import analyze_sentiment
from trading.agent import DQNAgent
from trading.train_agent import train_agent
from trading.binance_trader import BinanceTrader
from data.fear_and_greed import FearGreedIndexFetcher
from utils.adaptive_strategy import adapt_strategy


def handle_autotrade(bot, chat_id):
    symbols = bot.coin_manager.get_current_coins()
    trader = BinanceTrader()
    strategy_params = adapt_strategy()  # Загружаем адаптивные параметры стратегии

    bot.send_message(chat_id, f"🤖 Запускаю автотрейдинг для: {', '.join(symbols)}")

    # Получаем текущий баланс один раз
    balance = trader.exchange.fetch_balance()['free']['USDT']
    risk_percent = 0.02  # 2% риска на сделку

    for symbol in symbols:
        historical_data = bot.data_fetcher.fetch_historical_data_multi_timeframe(symbol)

        if not historical_data or '1h' not in historical_data or historical_data['1h'].empty:
            bot.send_message(chat_id, f"⚠️ Нет данных по {symbol}, пропускаем.")
            continue

        df = historical_data['1h']  # Основной таймфрейм для быстрого анализа (можешь выбрать другой)
        features = ['close', 'rsi', 'ema', 'adx', 'atr', 'volume']
        scaler = MinMaxScaler()
        scaled_features = scaler.fit_transform(df[features])

        # Получаем sentiment и Fear & Greed Index
        sentiment_score = analyze_sentiment(symbol.split('/')[0], bot.sentiment_analyzer)
        fear_greed_value, _ = FearGreedIndexFetcher.fetch_current_index()
        fear_greed_scaled = fear_greed_value / 100 if fear_greed_value else 0.5

        # Текущее состояние рынка (features + sentiment + fear_greed)
        current_state = np.append(scaled_features[-1], [sentiment_score, fear_greed_scaled])
        current_state_tensor = torch.tensor(current_state, dtype=torch.float32).unsqueeze(0)

        state_size = current_state_tensor.shape[1]
        action_size = 3
        agent = DQNAgent(state_size, action_size)

        model_path = f'trading/trained_agent_{symbol.replace("/", "_")}.pth'

        # Загрузка или обучение модели
        if os.path.exists(model_path):
            agent.model.load_state_dict(torch.load(model_path))
            agent.model.eval()
            bot.send_message(chat_id, f"✅ Модель для {symbol} успешно загружена!")
        else:
            bot.send_message(chat_id, f"⚙️ Модель для {symbol} не найдена, запускаю обучение (~2 мин.)...")
            agent = train_agent(symbol, sentiment_analyzer=bot.sentiment_analyzer, episodes=30)

        # Агент принимает решение
        action = agent.act(torch.tensor(np.append(scaled_features[-1], [fear_greed_scaled, sentiment_score]), dtype=torch.float32).unsqueeze(0))

        if action == 0:
            bot.send_message(chat_id, f"⏳ {symbol}: агент решил не торговать.")
            continue

        side = 'buy' if action == 1 else 'sell'

        # Расчёт ATR для текущего символа
        from data.atr import calculate_atr
        atr = calculate_atr(df)

        # Закрываем позиции если есть
        position = trader.get_position(symbol)
        if position:
            trader.close_all_positions(symbol)
            bot.send_message(chat_id, f"🔄 Закрыта текущая позиция по {symbol}.")

        # Открытие новой позиции с адаптивными параметрами
        trader.create_order_with_sl_tp(
            symbol=symbol,
            side=side,
            balance=balance,
            risk_percent=risk_percent,
            atr=atr,
            sl_multiplier=strategy_params.get('sl_multiplier', 1.5),
            tp_multiplier=strategy_params.get('tp_multiplier', 3)
        )

        message = (
            f"🚀 Открыта позиция {side.upper()} по {symbol}\n"
            f"💵 Цена: {df['close'].iloc[-1]:.2f}$\n"
            f"📊 ATR: {atr:.4f}\n"
            f"⚙️ Размер позиции: адаптивный\n"
            f"🔄 threshold_percent: {strategy_params['threshold_percent']:.2%}\n"
            f"🔮 Sentiment порог: {strategy_params['sentiment_threshold']:.2f}"
        )
        print(message)
        bot.send_message(chat_id, message)

    bot.send_message(chat_id, "✅ Проверка всех монет завершена!")
    bot.send_message(chat_id, f"🔄 Параметры стратегии адаптированы:\n"
                              f"threshold_percent: {strategy_params['threshold_percent']:.4f}\n"
                              f"sentiment_threshold: {strategy_params['sentiment_threshold']:.2f}")
