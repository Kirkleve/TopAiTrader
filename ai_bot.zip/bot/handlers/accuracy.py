import torch
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler


def handle_accuracy(bot, message, window_size=24):
    symbols = bot.coin_manager.get_current_coins()
    features = ['close', 'rsi', 'ema', 'adx', 'atr', 'volume']

    for symbol in symbols:
        market_data = bot.data_fetcher.fetch_historical_data_multi_timeframe(symbol)

        if '1h' not in market_data or market_data['1h'].empty:
            bot.send_message(message.chat.id, f"⚠️ Недостаточно данных для {symbol}.")
            continue

        df = market_data['1h']

        scaler = MinMaxScaler()
        scaled_features = scaler.fit_transform(df[features])

        X, y = [], []
        for i in range(len(scaled_features) - window_size):
            X.append(scaled_features[i:i + window_size])
            y.append(scaled_features[i + window_size, 0])

        X_tensor = torch.tensor(np.array(X), dtype=torch.float32)

        # Предсказания
        predictions = []
        bot.model.eval()
        with torch.no_grad():
            for i in range(X_tensor.shape[0]):
                pred = bot.model(X_tensor[i:i+1]).item()
                predictions.append(pred)

        # Обратная нормализация предсказаний
        dummy_pred = np.zeros((len(predictions), len(features)))
        dummy_pred[:, 0] = predictions
        predicted_prices = scaler.inverse_transform(dummy_pred)[:, 0]

        # Обратная нормализация реальных значений
        dummy_true = np.zeros((len(predictions), scaled_features.shape[1]))
        dummy_true[:, 0] = scaled_features[window_size:, 0]
        true_prices = scaler.inverse_transform(dummy_pred)[:, 0]

        # Расчет RMSE
        rmse = np.sqrt(mean_squared_error(true_prices, predicted_prices))

        result_message = (
            f"📊 *Точность модели для {symbol}:*\n"
            f"• Средняя ошибка прогноза: ±{rmse:.2f} USDT\n"
            "(чем ближе к 0, тем точнее прогноз)"
        )

        bot.send_message(message.chat.id, result_message, parse_mode='Markdown')
