import torch
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from bot.utils import analyze_sentiment
from data.fear_and_greed import FearGreedIndexFetcher

def handle_predict(bot, message, symbol='BTC/USDT'):
    # Загрузка данных нескольких таймфреймов и проверка наличия данных
    df_multi_tf = bot.data_fetcher.fetch_historical_data_multi_timeframe(symbol)
    if '1h' not in df_multi_tf or df_multi_tf['1h'].empty:
        bot.send_message(message.chat.id, f"⚠️ Нет данных по {symbol}.")
        return

    df_main = df_multi_tf['1h']

    # Индикаторы и масштабирование данных
    features = ['close', 'rsi', 'ema', 'adx', 'atr', 'volume']
    scaler = MinMaxScaler()
    scaled_features = scaler.fit_transform(df_main[features])

    # Подготовка данных для модели (окно 24 свечи)
    X_tensor = torch.tensor(scaled_features[-24:], dtype=torch.float32).unsqueeze(0)

    # Получаем прогноз модели
    prediction_norm = bot.model(X_tensor).item()

    # Делаем обратное масштабирование
    dummy: np.ndarray = np.zeros((1, scaled_features.shape[1]))
    dummy[0, 0] = prediction_norm
    predicted_price = scaler.inverse_transform(dummy)[0, 0]

    current_price = df_main['close'].iloc[-1]

    # Sentiment-анализ и Fear & Greed
    sentiment_score = analyze_sentiment(symbol.split('/')[0], bot.sentiment_analyzer)
    fear_greed_value, fear_greed_desc = FearGreedIndexFetcher.fetch_current_index()

    # Решение модели
    action = 'покупать 📈' if predicted_price > current_price else 'продавать 📉'

    # Причины принятия решения
    reasons = [
        f"RSI: {df_main['rsi'].iloc[-1]:.2f}",
        f"EMA: {'выше' if current_price > df_main['ema'].iloc[-1] else 'ниже'} текущей цены",
        f"ADX: {df_main['adx'].iloc[-1]:.2f} ({'сильный тренд' if df_main['adx'].iloc[-1] > 25 else 'слабый тренд'})",
        f"ATR: {df_main['atr'].iloc[-1]:.2f} (волатильность)",
        f"Sentiment: {'позитивный' if sentiment_score > 0 else 'негативный' if sentiment_score < 0 else 'нейтральный'} ({sentiment_score:.2f})",
        f"Fear & Greed: {fear_greed_value} ({fear_greed_desc})"
    ]

    decision_reasons = '\n'.join(['- ' + reason for reason in reasons])

    # Финальное сообщение пользователю
    final_message = (
        f"🔮 *Прогноз по {symbol}*\n"
        f"📍 Текущая цена: {current_price:.2f}$\n"
        f"🎯 Прогнозируемая цена: {predicted_price:.2f}$\n"
        f"🤖 Решение модели: *{action}*\n\n"
        f"📌 *Причины решения:*\n"
        f"{decision_reasons}"
    )

    bot.send_message(message.chat.id, final_message, parse_mode='Markdown')
