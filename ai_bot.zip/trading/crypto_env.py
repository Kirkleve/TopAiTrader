import gymnasium as gym
import numpy as np


class CryptoTradingEnv(gym.Env):
    def __init__(self, data, sentiment_scores, initial_balance=1000):
        super().__init__()

        self.data = data
        self.sentiment_scores = sentiment_scores
        self.initial_balance = initial_balance
        self.balance = initial_balance
        self.current_step = 0
        self.position = None
        self.position_price = 0

        self.action_space = gym.spaces.Discrete(3)  # BUY, SELL, HOLD

        obs_shape = data.shape[1] + 1
        self.observation_space = gym.spaces.Box(
            low=-np.inf, high=np.inf, shape=(obs_shape,), dtype=np.float32
        )

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.current_step = 0
        self.balance = self.initial_balance
        self.position = None
        self.position_price = 0

        observation = np.append(self.data[self.current_step], self.sentiment_scores[self.current_step])
        return observation, {}

    def step(self, action):
        reward = 0
        truncated = False
        current_price = self.data[self.current_step][0]

        if action == 0:  # BUY
            if self.position is None:
                self.position = 'long'
                self.position_price = current_price
            else:
                reward = -0.1

        elif action == 1:  # SELL
            if self.position is not None:
                profit = (current_price - self.position_price) / self.position_price
                self.balance *= (1 + profit)
                reward = profit * 100
                self.position = None
                self.position_price = 0
            else:
                reward = -0.1

        self.current_step += 1

        if self.current_step >= len(self.data) - 1:
            terminated = True
            truncated = True
        else:
            terminated = False

        observation = np.append(self.data[self.current_step], self.sentiment_scores[self.current_step])

        return observation, reward, terminated, truncated, {}

    def render(self):
        print(f"Step: {self.current_step}, Balance: {self.balance:.2f}, Position: {self.position}")
